using System;
using System.Collections.Generic;
using CommonObjects;
using Scripting;

namespace ScriptingInstance
{
	public class ScriptingInstance : SignalBase
	{
    	public int param_1 { get; set; }

		public ScriptingInstance()
		{
			Name = "ScriptingInstance";
		}

		protected override bool InternalInit(IEnumerable<Selection> selections)
		{
			Selections.AddRange(selections);
			
			// Your code initialization

			return true;
		}

		protected override void InternalStart(Selection instrument = null, IEnumerable<Tick> ticks = null)
		{
			// Your code run logic

			throw new NotImplementedException();
		}

		protected override List<ScriptingParameterBase> InternalGetParameters()
		{
			return new List<ScriptingParameterBase>();
		}

		protected override bool InternalSetParameters(List<ScriptingParameterBase> parameterBases)
		{
			return true;
		}

        protected override List<TradeSignal> BacktestSlotItem(IEnumerable<Selection> instruments, IEnumerable<object> parameters)
        {
            // Your backtest logic

            throw new NotImplementedException();
        }

        protected override OrderParams AnalyzePreTrade(OrderParams order)
        {
            // Your pre-trade analysis logic

            return order;
        }

        protected override void AnalyzePostTrade(Order order)
        {
            // Your post-trade analysis logic

        }

        protected override void ProcessTradeFailure(Order order, string error)
        {
            // Your order failure handler

        }
    }
}