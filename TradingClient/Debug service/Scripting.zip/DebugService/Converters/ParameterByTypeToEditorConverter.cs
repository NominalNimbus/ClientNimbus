﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Media;
using DebugService.Classes;
using Xceed.Wpf.Toolkit;
using Xceed.Wpf.Toolkit.Primitives;

namespace DebugService.Converters
{
    public class ParameterByTypeToEditorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null)
                return null;

            var valueBinding = new Binding("Value") { UpdateSourceTrigger = UpdateSourceTrigger.LostFocus };

            switch (value)
            {
                case IntParam intp:
                    return EditorConverterHelper.GetIntegerEditor(valueBinding, intp.MinValue, intp.MaxValue, intp.IsReadOnly);
                case DoubleParam doubleP:
                    return EditorConverterHelper.GetDoubleEditor(valueBinding, doubleP.MinValue, doubleP.MaxValue, doubleP.IsReadOnly);
                case StringParam stringP:
                    if (stringP.AllowedValues.Count > 0)
                        return EditorConverterHelper.GetComboboxEditor(valueBinding, stringP.AllowedValues);
                    else
                        return EditorConverterHelper.GetTextEditor(valueBinding);
                case BoolParam _:
                    return EditorConverterHelper.GetBoolCheckBoxEditor(valueBinding);
            }

            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
            throw new NotImplementedException();
    }

    internal static class EditorConverterHelper
    {
        public static IntegerUpDown GetIntegerEditor(Binding valuePropertyBinding, int minValue = Int32.MinValue, int maxValue = Int32.MaxValue, bool isReadOnly = false)
        {
            var control = new IntegerUpDown();
            SetNumericProperties(control, valuePropertyBinding, minValue, maxValue, isReadOnly);
            control.SetBinding(IntegerUpDown.ValueProperty, valuePropertyBinding);
            return control;
        }

        public static DoubleUpDown GetDoubleEditor(Binding valuePropertyBinding, double minValue = Double.MinValue, double maxValue = Double.MaxValue, bool isReadOnly = false)
        {
            var control = new DoubleUpDown();
            SetNumericProperties(control, valuePropertyBinding, minValue, maxValue, isReadOnly);
            control.SetBinding(DoubleUpDown.ValueProperty, valuePropertyBinding);
            return control;
        }

        public static TextBox GetTextEditor(Binding valuePropertyBinding)
        {
            var control = new TextBox();
            SetControlStyle(control);
            control.Foreground = Brushes.White;
            control.Background = new SolidColorBrush(Color.FromArgb(255, 50, 50, 50));
            control.SetBinding(TextBox.TextProperty, valuePropertyBinding);
            return control;
        }

        public static ComboBox GetBoolComboboxEditor(Binding valuePropertyBinding) =>
            GetComboboxEditor(valuePropertyBinding, new string[] { "true", "false" });


        public static ComboBox GetComboboxEditor(Binding valuePropertyBinding, IEnumerable<string> values)
        {
            var control = new ComboBox();
            SetControlStyle(control);
            foreach (var val in values)
            {
                control.Items.Add(val);
            }

            control.SetBinding(System.Windows.Controls.Primitives.Selector.SelectedItemProperty, valuePropertyBinding);
            return control;
        }

        public static CheckBox GetBoolCheckBoxEditor(Binding valuePropertyBinding)
        {
            var control = new CheckBox();
            SetControlStyle(control);
            control.Background = Brushes.White;
            control.SetBinding(CheckBox.IsCheckedProperty, valuePropertyBinding);
            control.HorizontalAlignment = HorizontalAlignment.Right;
            return control;
        }

        private static void SetNumericProperties<T>(CommonNumericUpDown<T> control, Binding valuePropertyBinding, T minValue, T maxValue, bool isReadOnly)
            where T : struct, IFormattable, IComparable<T>
        {
            SetControlStyle(control);
            control.Minimum = minValue;
            control.Maximum = maxValue;
            control.IsReadOnly = isReadOnly;
            control.SetBinding(IntegerUpDown.ValueProperty, valuePropertyBinding);
        }

        private static void SetControlStyle(Control control)
        {
            control.Background = Brushes.Transparent;
            control.BorderThickness = new Thickness(0);
            control.BorderBrush = Brushes.Transparent;
            control.Foreground = Brushes.Snow;
            control.Margin = new Thickness(3);
        }
    }
}
