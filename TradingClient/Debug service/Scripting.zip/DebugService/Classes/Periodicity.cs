﻿namespace DebugService.Classes
{
    public enum Periodicity
    {
        Minute,
        Hour,
        Day,
        Month
    }
}